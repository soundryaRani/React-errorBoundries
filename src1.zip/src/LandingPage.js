import React, { useState } from "react";

export const LandingPage = () => {
  const [value, setValue] = useState("");
  const ShowHandler = () => {
    let temp = Math.floor(Math.random() * 20);
    console.log(temp);
    setValue(temp);
  };
  if (value===10) {
    throw new Error("")
  }
  return (
    <div>
      <p>{value}</p>
      <button onClick={ShowHandler}>Show</button>
    </div>
  );
};

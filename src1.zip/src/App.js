import logo from './logo.svg';
import './App.css';
import ErrorPage from './ErrorPage';
import { LandingPage } from './LandingPage';

function App() {
  return (
    <div className="App">
      <ErrorPage>
      <LandingPage/>
      </ErrorPage>
    </div>
  );
}

export default App;

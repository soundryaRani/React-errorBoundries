import React, { Component } from 'react'

export default class ErrorPage extends Component {
    constructor(props){
        super(props)
        this.state={
            error:false,

        }
    }

    static getDerivedStateFromError(props){
        return{
            error:true
        }
    }

  render() {
    if(this.state.error){
        return <h2>Something went wrong</h2>
    }
    return this.props.children
  }
}